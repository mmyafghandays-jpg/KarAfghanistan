package afghanistan.kar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.util.Locale

data class Job(
    val title: String,
    val company: String,
    val city: String,
    val salary: String,
    val type: String,
    val description: String
)

private val sampleJobs = listOf(
    Job("کارمند اداری", "شرکت نمونه افغانستان", "کابل", "۱۵٬۰۰۰ افغانی", "تمام‌وقت",
        "انجام امور اداری، ثبت اسناد و هماهنگی با بخش‌های مختلف."),
    Job("فروشنده", "فروشگاه مرکزی", "غزنی", "۱۲٬۰۰۰ افغانی", "تمام‌وقت",
        "فروش محصولات، پاسخ‌گویی به مشتریان و تنظیم موجودی."),
    Job("توسعه‌دهنده اندروید", "شرکت فناوری افغانستان", "هرات", "۲۵٬۰۰۰ افغانی", "تمام‌وقت",
        "توسعه و نگهداری اپلیکیشن‌های Android و همکاری با تیم فنی.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KarAfghanistanApp() }
    }
}

@Composable
fun KarAfghanistanApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF176B87),
            secondary = androidx.compose.ui.graphics.Color(0xFF2E8B57)
        )
    ) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            var screen by remember { mutableStateOf("home") }
            var selectedJob by remember { mutableStateOf<Job?>(null) }

            Scaffold(
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            selected = screen == "home",
                            onClick = { screen = "home" },
                            icon = {},
                            label = { Text("خانه") }
                        )
                        NavigationBarItem(
                            selected = screen == "search",
                            onClick = { screen = "search" },
                            icon = {},
                            label = { Text("جستجو") }
                        )
                        NavigationBarItem(
                            selected = screen == "saved",
                            onClick = { screen = "saved" },
                            icon = {},
                            label = { Text("علاقه‌مندی") }
                        )
                        NavigationBarItem(
                            selected = screen == "profile",
                            onClick = { screen = "profile" },
                            icon = {},
                            label = { Text("پروفایل") }
                        )
                    }
                }
            ) { padding ->
                when (screen) {
                    "home" -> HomeScreen(Modifier.padding(padding)) { selectedJob = it }
                    "search" -> SearchScreen(Modifier.padding(padding)) { selectedJob = it }
                    "saved" -> SavedScreen(Modifier.padding(padding))
                    "profile" -> ProfileScreen(Modifier.padding(padding))
                }

                if (selectedJob != null) {
                    JobDetailsDialog(selectedJob!!) { selectedJob = null }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onJobClick: (Job) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("کار افغانستان", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("پل ارتباطی میان کارجویان و کارفرمایان افغانستان", color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(18.dp))

        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("جستجوی شغل، شرکت یا مهارت...") },
            singleLine = true
        )
        Spacer(Modifier.height(18.dp))

        Text("دسته‌بندی مشاغل", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("اداری", "ساختمانی", "فناوری", "آموزش").forEach {
                AssistChip(onClick = {}, label = { Text(it) })
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("جدیدترین فرصت‌های شغلی", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sampleJobs) { job -> JobCard(job, onJobClick) }
        }
    }
}

@Composable
fun SearchScreen(modifier: Modifier, onJobClick: (Job) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = sampleJobs.filter {
        query.isBlank() || it.title.contains(query, true) || it.city.contains(query, true)
    }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("جستجوی شغل", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("مثلاً: راننده، کابل، فروشنده") }
        )
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(results) { JobCard(it, onJobClick) }
        }
    }
}

@Composable
fun JobCard(job: Job, onClick: (Job) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick(job) },
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(job.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(job.company)
            Text("${job.city} • ${job.type}")
            Text(job.salary, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun JobDetailsDialog(job: Job, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(job.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("شرکت: ${job.company}")
                Text("مکان: ${job.city}")
                Text("معاش: ${job.salary}")
                Text("نوع کار: ${job.type}")
                Spacer(Modifier.height(12.dp))
                Text(job.description)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { }) {
                    Text("درخواست برای این شغل")
                }
                TextButton(onClick = onClose) { Text("بستن") }
            }
        }
    }
}

@Composable
fun SavedScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("علاقه‌مندی‌ها", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("هنوز شغلی ذخیره نشده است.")
    }
}

@Composable
fun ProfileScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("پروفایل", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("کارجو / کارفرما")
        Spacer(Modifier.height(12.dp))
        Button(onClick = {}) { Text("ورود / ثبت‌نام") }
        Spacer(Modifier.height(24.dp))
        HorizontalDivider()
        Spacer(Modifier.height(16.dp))
        Text("ارتباط با سازنده", fontWeight = FontWeight.Bold)
        Text("محمدرضا نجیبی")
        Text("0749239433", modifier = Modifier.padding(top = 4.dp))
        Text("m.reza.najibi", modifier = Modifier.padding(top = 4.dp))
    }
}
